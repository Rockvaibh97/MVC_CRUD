﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MvcDemo.Models
{
    public class Employees
    {
        [Key]
        public int Id { get; set; }
        [Column(TypeName="varchar(50)")]
        [Required]
        public string Name { get; set; }
        [Column(TypeName = "varchar(50)")]

        [Required]
        public string City { get; set; }
        [Column(TypeName = "varchar(50)")]

        [Required]
        public string Department { get; set; }
        [Column(TypeName = "varchar(50)")]

        [Required]
        public int Salary { get; set; }
    }
}
